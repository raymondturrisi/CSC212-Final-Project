#!/bin/bash

# Compiles with the following commands

g++ main.cpp -ggdb -o prog.exe

#/home/ubuntu/csc212/project/CSC212-Final-Project/data/breakdown_by_type/RI