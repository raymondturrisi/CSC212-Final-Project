#!/bin/bash

debug50 ./prog.exe /home/ubuntu/csc212/project/CSC212-Final-Project/data/breakdown_by_type/RI/coffee.csv